import streamlit as st
import sqlite3
from datetime import datetime as dt
from datetime import timedelta
import uuid
import pandas as pd


# اتصال به پایگاه داده SQL
conn = sqlite3.connect('2.db')
c = conn.cursor()

c.execute('''CREATE TABLE IF NOT EXISTS users(normal_username TEXT PRIMARY KEY,normal_password TEXT, active INTEGER DEFAULT 1, manager INTEGER DEFAULT 0)''')
c.execute('''CREATE TABLE IF NOT EXISTS projects(project_id INTEGER PRIMARY KEY NOT NULL,name TEXT)''')
c.execute('''CREATE TABLE IF NOT EXISTS members(username_user TEXT PRIMARY KEY NOT NULL ,project_id INTEGER,FOREIGN KEY (project_id) REFERENCES projects(project_id))''')
c.execute('''CREATE TABLE IF NOT EXISTS tasks(task_uniq_pass TEXT PRIMARY KEY NOT NULL,task_name TEXT, task_dscr TEXT,start_day DATE, end_day DATE,task_priority TEXT,task_status TEXT,project_id INTEGER,username_user TEXT,FOREIGN KEY (project_id) REFERENCES projects(project_id) ,FOREIGN KEY (username_user) REFERENCES members(username_user))''')
c.execute('''CREATE TABLE IF NOT EXISTS comments(comment_id INTEGER PRIMARY KEY , user_comment TEXT, username_user TEXT, task_uniq_pass TEXT, start_day DATE, FOREIGN KEY (task_uniq_pass) REFERENCES tasks(task_uniq_pass), FOREIGN KEY (username_user) REFERENCES members(username_user))''')
c.execute('''CREATE TABLE IF NOT EXISTS history(history_id TEXT PRIMARY KEY NOT NULL,change_task_pass TEXT,username_user TEXT ,change_time DATE,change_priority TEXT ,change_status TEXT,FOREIGN KEY (change_task_pass) REFERENCES tasks(task_uniq_pass),FOREIGN KEY (username_user) REFERENCES members(username_user))''')


def add_user(normal_username, normal_password, active, manager):
    c.execute('INSERT INTO users (normal_username, normal_password, active, manager) VALUES (?,?,?,?)', (normal_username, normal_password, active, manager))
    conn.commit()

def search_users(normal_username):
    c.execute('SELECT * FROM users WHERE normal_username =?', (normal_username,))
    return c.fetchone()

def add_manager(normal_username, normal_password, active, manager):
    c.execute('INSERT INTO users (normal_username, normal_password, active, manager) VALUES (?,?,?,?)', (normal_username, normal_password, active, manager))
    conn.commit()

def deactivate_regular_user(normal_username):
    c.execute('UPDATE users SET active = 0 WHERE normal_username = ?', (normal_username,))
    conn.commit()

def activate_regular_user(normal_username):
    c.execute('UPDATE users SET active = 1 WHERE normal_username = ?', (normal_username,))
    conn.commit()


st.title('صفحه کاربری شخصی')


with st.form(key='add_user'):
    st.subheader("ثبت نام")
    normal_username = st.text_input('نام کاربری')
    normal_password = st.text_input('رمز عبور')
    submit_button = st.form_submit_button(label='ثبت نام کاربر')
    manager_button = st.form_submit_button(label='ثبت نام مدیر')

if submit_button:
    add_user(normal_username, normal_password,active=1,manager=0)
    st.success('کاربر با موفقیت اضافه شد!')
if manager_button:
    add_manager(normal_username, normal_password,active=1,manager=1)
    st.success('مدیر با موفقیت اضافه شد!')

with st.form(key='login_form'):
    st.subheader("ورود")
    login_username = st.text_input('نام کاربری', key='login_username')
    login_password = st.text_input('رمز عبور', type='password', key='login_password')
    login_button = st.form_submit_button(label='ورود')

    if login_button:
        user = search_users(login_username)
        if user and user[1] == login_password:
            if user[2] == 1:  # بررسی وضعیت active
                st.session_state['logged_in'] = True
                st.session_state['user_role'] = 'مدیر'
                st.success(f'خوش آمدید {login_username}! شما به عنوان مدیر وارد شده‌اید.')
                def page1():
                    st.title('')
                page1()
            else:
                st.session_state['logged_in'] = True
                st.session_state['user_role'] = 'کاربر عادی'
                st.success(f'خوش آمدید {login_username}!')
        else:
            st.error('نام کاربری یا رمز عبور اشتباه است.')


if 'logged_in' in st.session_state and st.session_state['logged_in']:
    if st.session_state['user_role'] == 'مدیر':
        st.subheader('مدیریت کاربران')
        with st.form(key='deactivate_user_form'):
            deactivate_username = st.text_input('نام کاربری کاربر عادی برای غیرفعال کردن')
            deactivate_button = st.form_submit_button(label='غیرفعال کردن کاربر')

            if deactivate_button:
                user_exist = search_users(deactivate_username)
                if user_exist:
                    deactivate_regular_user(deactivate_username)
                    st.success(f'حساب کاربری {deactivate_username} با موفقیت غیرفعال شد.')
                else:
                    st.error('کاربری با این نام کاربری وجود ندارد.')

        with st.form(key='activate_user_form'):
            activate_username = st.text_input('نام کاربری کاربر عادی برای فعال کردن')
            activate_button = st.form_submit_button(label='فعال کردن کاربر')

        if activate_button:
            user_entry = search_users(activate_username)
            if user_entry:
                activate_regular_user(activate_username)
                st.success(f'حساب کاربری {activate_username} با موفقیت فعال شد.')
            else:
                st.error('کاربری با این نام کاربری فعال نشد.')
    else:
        st.warning('شما مجوز لازم برای انجام این عملیات را ندارید.')
else:
    st.warning('لطفاً وارد شوید.')


def page2():

    
    def add_project(project_id,name):
        c.execute('INSERT INTO projects (project_id, name) VALUES (?,?)', (project_id , name,))
    conn.commit()

    def delete_project(project_id , name):
        c.execute('DELETE FROM projects WHERE project_id = ? AND name = ?', (project_id ,name))
        conn.commit()

    def add_member(username_user,project_id): 
        c.execute('SELECT normal_username FROM users WHERE normal_username=?', (username_user,))
        existing_username = c.fetchone()
        if existing_username:
            c.execute('INSERT INTO members (username_user, project_id) VALUES (?, ?)', (username_user, project_id))
            conn.commit()

    def delete_member(username_user,project_id):
        c.execute('DELETE FROM members WHERE username_user=? AND project_id=?' , (username_user,project_id))
        conn.commit()
        
    def add_task(task_uniq_pass,task_name,task_dscr,start_day,end_day,task_priority,task_status,project_id ,username_user):
        c.execute('INSERT INTO tasks (task_uniq_pass,task_name, task_dscr, start_day, end_day, task_priority, task_status, project_id, username_user) VALUES (?,?,?,?,?,?,?,?,?)', (task_uniq_pass,task_name, task_dscr,start_day,end_day,task_priority,task_status,project_id,username_user))
        conn.commit()

    def delete_task(task_uniq_pass,task_name,task_dscr,start_day,end_day,task_priority,task_status,project_id ,username_user):
        c.execute('DELETE FROM tasks WHERE  task_name=? AND task_dscr=? AND start_day=? AND end_day=? AND task_priority=? AND task_status=? AND project_id=? AND username_user=? (?,?,?,?,?,?,?)', (task_uniq_pass,task_name, task_dscr,start_day,end_day,task_priority,task_status,project_id,username_user))
        conn.commit()

    def add_comment(user_comment, username_user, task_uniq_pass,start_day):
        c.execute('SELECT project_id FROM tasks WHERE task_uniq_pass=?', (task_uniq_pass,))
        task_project_id = c.fetchone()
        if task_project_id:
            c.execute('SELECT project_id FROM members WHERE username_user=?', (username_user,))
            members_in_project_id = c.fetchall()
            if task_project_id in members_in_project_id:
                c.execute('INSERT INTO comments (user_comment, username_user, task_uniq_pass, start_day) VALUES (?,?,?,?)', (user_comment, username_user, task_uniq_pass, start_day))
                conn.commit()
                return 'کامنت با موفقیت اضافه شد!'
            else:
                return 'کاربر عضو پروژه مربوط به این وظیفه نیست.'
        else:
            return 'وظیفه‌ای با این شناسه یافت نشد.'

    def change_task(task_uniq_pass,task_name,task_dscr,start_day,end_day,task_priority,task_status,project_id ,username_user):
        c.execute('''REPLACE INTO tasks (task_uniq_pass, task_name, task_dscr, start_day, end_day, task_priority, task_status, project_id, username_user) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''', (task_uniq_pass, task_name, task_dscr, start_day, end_day, task_priority, task_status, project_id, username_user))
        change_task_pass =task_uniq_pass
        history_username_user = username_user
        change_priority=task_priority
        change_status=task_status
        def change_history(change_task_pass, history_username_user, change_priority, change_status):
            history_id = str(uuid.uuid4())
            change_time = dt.now()
            c.execute('''INSERT INTO history (history_id, change_task_pass, username_user, change_time, change_priority, change_status)VALUES (?, ?, ?, ?, ?, ?)''', (history_id, change_task_pass, history_username_user, change_time, change_priority, change_status))
        change_history(change_task_pass ,history_username_user,change_priority,change_status)
        conn.commit()
        
        
        
        st.title('سیستم مدیریت پروژه')

    with st.form(key='add_project'):
        st.subheader("راهبر پروژه")
        st.subheader("مشخصات پروژه")
        project_id = st.text_input('شناسه پروژه')
        name = st.text_input('عنوان پروژه')
        submit_button = st.form_submit_button(label='اضافه کردن پروژه')
        
        if submit_button:
            add_project(project_id,name)
            st.success('پروژه جدید با موفقیت اضافه شد!')

    with st.form(key='delete_project'):
        st.subheader("حذف پروژه")
        st.caption("حذف پروژه")
        project_id = st.text_input('شناسه پروژه')
        name = st.text_input('عنوان پروژه')

        deleteuser_button = st.form_submit_button(label='حذف پروژه')
        if deleteuser_button:
            delete_project(project_id,name)
            st.success('پروژه با موفقیت حذف شد!')

    with st.form(key='add_member'):
        st.subheader("افزودن کاربر")
        username_user=st.text_input("نام کاربری کاربر جدید")
        project_id=st.text_input("شناسه پروژه مدنظر")
        deleteuser_button = st.form_submit_button(label='اضافه کردن کاربر')
        if deleteuser_button:
            add_member(username_user , project_id)
            st.success('کاربر جدید با موفقیت اضافه شد!')
            
            
    with st.form(key='delete_member'):
        st.subheader("حذف کردن کاربر")
        username_user=st.text_input("نام کاربری کاربر")
        project_id=st.text_input("شناسه پروژه مدنظر")
        deleteuser_button = st.form_submit_button(label='حذف کردن کاربر')
        if deleteuser_button:
            delete_member(username_user , project_id)
            st.success('کاربر جدید با موفقیت اضافه شد!')
        

    with st.form(key='add_tasks'):
        st.subheader("افزودن وظیفه")
        task_uniq_pass = str(uuid.uuid4())
        task_name = st.text_input('عنوان وظیفه')
        task_dscr = st.text_input('توضیحات وظیفه')
        project_id= st.text_input('َشناسه پروژه مدنظر')
        username_user= st.text_input('کاربر مدنظر برای قراردادن وظیفه')
        task_priority= st.text_input('اولویت وظیفه')
        priority_degrees=("CRITICAL" , "HIGH" , "MEDIUM" , "LOW")
        task_status= st.text_input('وضغیت وظیفه')
        status_degrees= ("BACKLOG" , "TODO" , "DOING" , "DONE" , "ARCHIVED")
        start_day =  dt.now() 
        end_day = start_day + timedelta(hours=24)
        db_qeury = "SELECT task_name , username_user FROM tasks"
        Assignees=st.write(pd.read_sql_query(db_qeury, conn))
        
        addtask_button = st.form_submit_button(label='اضافه کردن وظیفه')
        
        if addtask_button:
            if not task_priority:
                task_priority = "LOW"
            if not task_status:
                task_status = "BACKLOG"
            if task_priority in priority_degrees:
                if task_status in status_degrees :                
                    True_task_priority = task_priority
                    True_task_status = task_status
                    add_task(task_uniq_pass,task_name,task_dscr,start_day,end_day,True_task_priority,True_task_status,project_id,username_user)
                    st.success('پروژه جدید با موفقیت اضافه شد!')
                else:
                    st.error('وضعیت پروژه اشتباه است!')
            else:
                st.error('اولویت پروژه اشتباه است!')

    with st.form(key='delete_tasks'):
        st.subheader("حذف وظیفه")
        task_uniq_pass = str(uuid.uuid4())
        task_name = st.text_input('عنوان وظیفه')
        task_dscr = st.text_input('توضیحات وظیفه')
        project_id= st.text_input('َشناسه پروژه مدنظر')
        username_user= st.text_input('کاربر مدنظر برای قراردادن وظیفه')
        task_priority= st.text_input('اولویت وظیفه')

        deltask_button = st.form_submit_button(label='حذف کردن وظیفه')
        
        if deltask_button:
            delete_task(task_uniq_pass,task_name,task_dscr,start_day,end_day,True_task_priority,True_task_status,project_id,username_user)
            st.success('پروژه جدید با موفقیت اضافه شد!')


    with st.form(key='change_tasks'):
        st.subheader("تغییر وظیفه")
        task_uniq_pass = str(uuid.uuid4())
        task_name = st.text_input('عنوان وظیفه')
        task_dscr = st.text_input('توضیحات وظیفه')
        project_id= st.text_input('َشناسه پروژه مدنظر')
        username_user= st.text_input('کاربر مدنظر برای قراردادن وظیفه')
        task_priority= st.text_input('اولویت وظیفه')
        priority_degrees=("CRITICAL" , "HIGH" , "MEDIUM" , "LOW")
        task_status= st.text_input('وضغیت وظیفه')
        status_degrees= ("BACKLOG" , "TODO" , "DOING" , "DONE" , "ARCHIVED")
        start_day =  dt.now() 
        end_day = start_day + timedelta(hours=24)
        db_qeury = "SELECT task_name , username_user FROM tasks"
        Assignees=st.write(pd.read_sql_query(db_qeury, conn))
        addtask_button = st.form_submit_button(label='تغییر وظیفه')
        
        if addtask_button:
            if not task_priority:
                task_priority = "LOW"
            if not task_status:
                task_status = "BACKLOG"
            if task_priority in priority_degrees:
                if task_status in status_degrees :                
                    True_task_priority = task_priority
                    True_task_status = task_status
                    change_task(task_uniq_pass,task_name,task_dscr,start_day,end_day,True_task_priority,True_task_status,project_id,username_user)
                    st.success('پروژه جدید با موفقیت اضافه شد!')
                else:
                    st.error('وضعیت پروژه اشتباه است!')
            else:
                st.error('اولویت پروژه اشتباه است!')
        
    with st.form(key='comments'):
        st.subheader("کامنت ها")
        user_comment = st.text_input('کامنت')
        username_user = st.text_input('شناسه کاربر')
        task_uniq_pass= st.text_input('َشناسه وظیفه مدنظر')
        start_day =  dt.now() 
        db_qeury = "SELECT user_comment ,task_uniq_pass FROM tasks  "
        Assignees=st.write(pd.read_sql_query(db_qeury, conn))
        comments_button = st.form_submit_button(label='تغییر وظیفه')
        
        if comments_button:
                    add_comment(user_comment, username_user, task_uniq_pass, start_day)
                    st.success('پروژه جدید با موفقیت اضافه شد!')


page2_button = st.form_submit_button(label='رفتن به سیستم مدیریت پروژه')
if page2_button:
    page2()


conn.close()