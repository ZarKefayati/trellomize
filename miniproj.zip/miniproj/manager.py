import streamlit as st
import sqlite3

# اتصال به پایگاه داده SQL
conn = sqlite3.connect('manager.db')
c = conn.cursor()

# ایجاد جدول‌های مدیران و کاربران اگر وجود ندارند
c.execute('''CREATE TABLE IF NOT EXISTS managers(username TEXT PRIMARY KEY,password TEXT)''')
c.execute('''CREATE TABLE IF NOT EXISTS regular_users(username TEXT PRIMARY KEY,password TEXT, active INTEGER DEFAULT 1)''')
conn.commit()

# توابع برای اضافه کردن مدیران و کاربران عادی
def add_manager(username, password):
    c.execute('INSERT INTO managers (username, password) VALUES (?,?)', (username, password))
    conn.commit()

def add_regular_user(username, password):
    c.execute('INSERT INTO regular_users (username, password, active) VALUES (?,?,1)', (username, password))
    conn.commit()

# توابع برای جستجوی مدیران و کاربران عادی
def search_manager(username):
    c.execute('SELECT * FROM managers WHERE username =?', (username,))
    return c.fetchone()

def search_regular_user(username):
    c.execute('SELECT * FROM regular_users WHERE username =?', (username,))
    return c.fetchone()

# تابع برای غیرفعال کردن کاربر عادی
def deactivate_regular_user(username):
    c.execute('UPDATE regular_users SET active = 0 WHERE username = ?', (username,))
    conn.commit()

def activate_regular_user(username):
    c.execute('UPDATE regular_users SET active = 1 WHERE username = ?', (username,))
    conn.commit()

# ساخت صفحه وب با Streamlit
st.title('صفحه کاربری شخصی')

# فرم ثبت نام مدیر
with st.form(key='manager_register_form'):
    username = st.text_input('نام کاربری مدیر')
    password = st.text_input('رمز عبور مدیر', type='password')
    submit_button = st.form_submit_button(label='ثبت نام مدیر')

if submit_button:
    add_manager(username, password)
    st.success('مدیر با موفقیت اضافه شد!')

# فرم ثبت نام کاربر عادی
with st.form(key='regular_user_register_form'):
    username = st.text_input('نام کاربری کاربر عادی')
    password = st.text_input('رمز عبور کاربر عادی', type='password')
    submit_button = st.form_submit_button(label='ثبت نام کاربر عادی')

    if submit_button:
        add_regular_user(username, password)
        st.success('کاربر عادی با موفقیت اضافه شد!')

# فرم ورود
with st.form(key='login_form'):
    login_username = st.text_input('نام کاربری', key='login_username')
    login_password = st.text_input('رمز عبور', type='password', key='login_password')
    login_button = st.form_submit_button(label='ورود')

    if login_button:
        manager_info = search_manager(login_username)
        regular_user_info = search_regular_user(login_username)
        if manager_info and manager_info[1] == login_password:
            st.session_state['logged_in'] = True
            st.session_state['user_role'] = 'مدیر'
            st.success(f'خوش آمدید {login_username}! شما به عنوان مدیر وارد شده‌اید.')
            def page1():
                st.title('')
            page1()
            
        elif regular_user_info and regular_user_info[1] == login_password:
            if regular_user_info[2]:  # بررسی وضعیت active
                st.session_state['logged_in'] = True
                st.session_state['user_role'] = 'کاربر عادی'
                st.success(f'خوش آمدید {login_username}!')
            else:
                st.error('حساب کاربری شما غیرفعال شده است.')
        else:
            st.error('نام کاربری یا رمز عبور اشتباه است.')

# بخش مدیریتی در صفحه مدیر
if 'logged_in' in st.session_state and st.session_state['logged_in'] and st.session_state['user_role'] == 'مدیر':
    st.subheader('مدیریت کاربران')
    with st.form(key='deactivate_user_form'):
        deactivate_username = st.text_input('نام کاربری کاربر عادی برای غیرفعال کردن')
        deactivate_button = st.form_submit_button(label='غیرفعال کردن کاربر')

        if deactivate_button:
            user_exist = search_regular_user(deactivate_username)
            if user_exist:
                deactivate_regular_user(deactivate_username)
                st.success(f'حساب کاربری {deactivate_username} با موفقیت غیرفعال شد.')
            else:
                st.error('کاربری با این نام کاربری وجود ندارد.')

    with st.form(key='activate_user_form'):
        activate_username = st.text_input('نام کاربری کاربر عادی برای فعال کردن')
        activate_button = st.form_submit_button(label='فعال کردن کاربر')

        if activate_button:
            user_entry = search_regular_user(activate_username)
            if user_entry:
                activate_regular_user(deactivate_username)
                st.success(f'حساب کاربری {deactivate_username} با موفقیت فعال شد.')
            else:
                st.error('کاربری با این نام کاربری فعال نشد.')

conn.close()

