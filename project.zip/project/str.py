import streamlit as st

st.title("TITLE")
st.write("enter your account")
st.markdown("This is markdown")
st.header("Header")
st.subheader("subHeader")
st.caption("capti   on")
st.code("X=2021")
# st.image("image.jpg", caption='any explain..', use_column_width=True)

name=st.text_input("name: ")
if st.button("sent "):
    if name :
        st.success('successfully :) ')


with st.form("sub"):
    email= st.text_input("Email")
    submit = st.form_submit_button("sent")
    if submit:
        new_record = {"email" : email}
        st.write("successfuly :) ") 
        
        
        
def page1():
    st.title('P1')
    
def page2():
    st.title("P2")
    
if st.button("Go p1"):
    page1()

if st.button("Go p2"):
    page2()