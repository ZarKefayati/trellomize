from sqlalchemy import create_engine
import pandas as pd

import pyodbc

# اتصال به پایگاه داده SQL
conn = pyodbc.connect('DRIVER={SQL Server};SERVER=server_name;DATABASE=db_name;UID=username;PWD=password')

# نام جدول مورد نظر
table_name = 'your_table_name'

# اجرای دستور SQL برای نمایش فیلدها
query = f"SELECT * FROM {table_name}"
df = pd.read_sql(query, conn)

# نمایش آماره‌های فیلدهای عددی
numeric_stats = df.describe()
print(numeric_stats)
