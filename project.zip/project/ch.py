# if submit_button:
#     if existing_manager:
#         search_manager(username)
#         existing_manager = c.fetchone()
#         st.error('این مدیر قبلاً ثبت شده است.')
        
#     else: 
#         add_manager(username, password)
#         st.success('مدیر با موفقیت اضافه شد!')

# # فرم ثبت نام کاربر عادی
# with st.form(key='regular_user_register_form'):
#     username = st.text_input('نام کاربری کاربر عادی')
#     password = st.text_input('رمز عبور کاربر عادی', type='password')
#     submit_button = st.form_submit_button(label='ثبت نام کاربر عادی')

#     if submit_button:
#         search_regular_user(username)
#         existing_user=c.fetchone()
#         if existing_user:
#             st.error('این کاربر عادی قبلاً ثبت شده است.')
#         else :
#             add_regular_user(username, password)
#             st.success('کاربر عادی با موفقیت اضافه شد!')

