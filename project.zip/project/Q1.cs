using System;
using System.Collections.Generic;

class Program
{
    static int N, M, K;
    static List<(int, int, int)> conn; // (u, v, w)
    static void Main()
    {
        inp();
        int result = FindMinimumTime();
        Console.WriteLine(result);
    }
    static void inp()
    {
        string[] input = Console.ReadLine().Split();
        N = int.Parse(input[0]);
        M = int.Parse(input[1]);
        K = int.Parse(input[2]);

        conn = new List<(int, int, int)>();
        for (int i = 0; i < M; i++)
        {
            input = Console.ReadLine().Split();
            int u = int.Parse(input[0]);
            int v = int.Parse(input[1]);
            int w = int.Parse(input[2]);
            conn.Add((u, v, w));
        }
    }

    static int FindMinimumTime()
    {
    distances[1] = 0

    # Priority queue to keep track of vertices with minimum distance
    pq = [(0, 1)]  # (distance, vertex)

    while pq:
        dist_u, u = heapq.heappop(pq)

        # Relax edges from vertex u
        for v, w in conn:
            if u == v:
                continue
            if distances[u] + w < distances[v]:
                distances[v] = distances[u] + w
                heapq.heappush(pq, (distances[v], v))

    return distances[N]

    }
}
