import heapq


def read_input():
    global N, M, K, connections
    N, M, K = map(int, input().split())
    connections = []
    for _ in range(M):
        u, v, w = map(int, input().split())
        connections.append((u, v, w))

def find_minimum_time():
    distances = [float('inf')] * (N + 1)
    distances[1] = 0

    # Priority queue to keep track of vertices with minimum distance
    pq = [(0, 1)]  # (distance, vertex)

    while pq:
        dist_u, u = heapq.heappop(pq)

        # Relax edges from vertex u
        for v, w in connections:
            if u == v:
                continue
            if distances[u] + w < distances[v]:
                distances[v] = distances[u] + w
                heapq.heappush(pq, (distances[v], v))

    return distances[N]

if __name__ == "__main__":
    read_input()
    result = find_minimum_time()
    print(result)
